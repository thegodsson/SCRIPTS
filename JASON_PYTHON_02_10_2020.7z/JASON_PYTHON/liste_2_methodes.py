
"""
inventaire = []

print(inventaire[:])

#Ajouté un éléments dans la liste en fin de liste
inventaire.append("Arc")

print(inventaire[:])

inventaire.append("Bouclier")


print(inventaire[:])
"""

"""
inventaire = ["Arc", "Bouclier", "Manteau de cuir"]

print(inventaire[:])

#Ajouté un élément au 2eme élément(2eme place) donc à l'indice 1
#inventaire.insert(1, "epee")

#Supprimé un élément
#technique 1 On est obliqé de mettre l'element et non l'indice
#inventaire.remove("Bouclier")

#technique2 supprimer grace à l'indice on vas utilisé "del"
#del(inventaire[1])


print(inventaire[:])
"""

"""
inventaire = ["Arc", "Bouclier", "Manteau de cuir"]

print(inventaire[:])

#Rechercher l'indice d'un element d'une liste
#print("Indice de bouclier : ", inventaire.index("Bouclier"))

objet_a_supprimer = inventaire.index("Bouclier")


del(inventaire[objet_a_supprimer])

print(inventaire[:])
"""

"""

inventaire = ["Potion de mana", "Arc", "Bouclier", "Manteau de cuir", "Arbalète"]

print(inventaire[:])

#Trier une liste

inventaire.sort()

print(inventaire[:])

"""

"""
inventaire = [10, 2000, 1, 60, -1, 78, -2000]

print(inventaire[:])

#Trieer par ordre croissant
#inventaire.sort()

#Inversé une liste
inventaire.reverse()

print(inventaire[:])
"""

"""
inventaire = ["potion", "arc", "potion", "potion", "manteau"]



print(inventaire[:])

#Calculer le nombre de fois on trouve l'occurence "potion" dans la liste

print("Nombre de potions : ", inventaire.count("potion"))
"""

#Donne les methode pour les liste
#help(list)



inventaire = ["potion", "arc", "potion", "potion", "manteau"]

#effacer une liste

"""
print(inventaire[:])

inventaire = []

print(inventaire[:])
"""

#Autre technique pour effacer

"""
print(inventaire[:])

inventaire.clear()

print(inventaire[:])
"""

#On coupe une chaine de caractère en liste
chaine = "Bonjour à tous"

chaine = chaine.split(" ")

#print(chaine)

#On vas creer une liste que l'on vas transformé en chaine de caractère

"""

inventaire_2 = ["Bonjour", "à", "tous"]

print(inventaire_2[:])

#phrase = " ".join(inventaire_2)
phrase = "_".join(inventaire_2)


print(phrase)
"""



"""
#Rappel une chaine de caracrète creer une copie, sur une liste on agit direcetement

#CHAINE DE CARARCTERE:

chaine1 = "COMENT ALLEZ VOUS"
chaine2 = chaine1

print(chaine1)
print(chaine2)

chaine1 = chaine1.lower()


print(chaine1)
print(chaine2)

#Sauf la chaine de caratère chaine1 est modifier, car chaine2 est une copie de sauvegarde si on veut à un instant T

#LISTE

liste1 = ["COMMENT", "ALLEZ", "VOUS"]
liste2 = liste1

print(liste1)
print(liste2)

liste1.append("BIEN")

print(liste1)
print(liste2)


#Ici les 2 liste sont modifier
"""







"""

#ASTUCE SI POUR UNE RAISON VOUS VOULEZ FAIRE UNE COPIE DE SAUVEGRADE DUNE LISTE

import copy

liste1 = ["COMMENT", "ALLEZ", "VOUS"]

liste2 = copy.deepcopy(liste1)

print(liste1)
print(liste2)

liste1.append("BIEN")

print(liste1)
print(liste2)

"""

"""

#AJOUTER UNE LISTE A UNE AUTRE LISTE

#1 Rappel avec les chaine de caractere

chaine1 = "Bonjour comment vas tu"
chaine2 = " Bien"
chaine3 = chaine1 + chaine2
#print(chaine3)


#Avec les liste

liste1 = ["ARC", "Bouclier", "Tunique"]
liste2 = ["Potion de mana", "Bijoux"]


print(liste1[:])
print(liste2[:])


#1ere technique:
#liste1.extend(liste2)

#2eme tecehnique

#liste1 = liste1 + liste2
liste1 += liste2


print(liste1[:])
"""


inventaire = ["ARC", "Epee", "Bouclier", "Potion"]


#for objet in inventaire:
#    print(objet)

#On veut l'indice et la valeur, on vas utilisé : enumerate


#for objet in enumerate(inventaire):
#    print(objet)



#Recuperation de l'indice

for indice_objet, valeur_objet in enumerate(inventaire):
    print("L'indice  de {} est  de : {} ".format(valeur_objet, indice_objet))



































































































 








































































































































