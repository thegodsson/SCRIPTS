
phrase = "Magicien|10|5"

ch = "bonjour"


"""
if ch.islower():
    print("Minuscule")
else:
    print("La chaine contient des majuscule")

"""
"""
ch2 = "class"

if ch2.isidentifier():   # Ne fonctionne pas bien
    print("Réservé")
else:
    print("Libre")
"""
#print(phrase.split("|"))


ch3 = "Le langage python"

if "toto" in ch3:
    print("Trouvé")
else:
    print("Non trouvé")

  

 