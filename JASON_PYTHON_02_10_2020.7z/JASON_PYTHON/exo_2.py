
#Classe mère
class Age:
    def __init__(self):
           
        while True:
            try:
                self.age = int(input("Quel âge avez-vous ? : "))
            except:
                print("Veuillez entrer un nombre SVP : ")
                continue
            else:
                print("Bonjour vous avez {} ans ".format(self.age))
                break

#Classe fille
class Maj(Age):
    def __init__(self,age_maj):
        Age.__init__(self)
        self.age_maj = age_maj

        if self.age < 18:
            print("Vous ête Mineur")
        else:
            print("Vous ête Majeur")

###Programme Principal
#pers1 = Age()
pers2 = Maj(10)