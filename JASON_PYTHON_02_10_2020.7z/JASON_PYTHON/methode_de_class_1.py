#coding:utf-8

class Humain:

    """
    classe qui definit les humain
    """

    #Création d'une méthode de classe:
    lieu_habitation = "Terre"


    def __init__(self, h_nom, h_age):   #self = méthode standard
        self.nom = h_nom
        self.age = h_age

    #Création de notre premiere methode ce n'est pas une methode classe, c'est une instance ou une methode simple:
    def parler(self, message):
        print("{} {} a dit :  {} ".format(self.nom, self.age, message))


    #Application de notre méthode de classe:
    def changer_planete(cls, nouvelle_planete):         #cls = methode de classe
        Humain.lieu_habitation = nouvelle_planete

    changer_planete = classmethod(changer_planete)

    #Création d'une methode statique:
    def definition():
        print("Numero 1 de la chaine alimentaire...")

    definition = staticmethod(definition)

####################
####################
#Programme principal
h1 = Humain("David", 38)

#h1.parler("Bonjour tout le monde")
print("Planete actuelle : {} ".format(Humain.lieu_habitation))

Humain.changer_planete("MARS")

print("Planete actuelle : {} ".format(Humain.lieu_habitation))

Humain.definition()