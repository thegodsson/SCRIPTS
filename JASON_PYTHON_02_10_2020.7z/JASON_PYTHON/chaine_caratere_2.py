

ma_chaine = "Bonjour tout le monde"
ma_chaine2 = "Salut comment allez vous"
ma_chaine3 = "Ki gen ar"
ma_chaine4 = "An la posé"
ma_chaine5 = "    Toujou o comba    "
#ma_chaine6 = "negusä nägäst"
ma_chaine6 = "AAAAAAAAAAAAAA BBBBBBBBBB ZZZZZZZZZ"

ma_chaine = ma_chaine.title()
ma_chaine2 = ma_chaine2.center(200, "-")
ma_chaine5 = ma_chaine5.strip()


#print(ma_chaine)
#print(ma_chaine2)
#print(ma_chaine3.find("gen"))
#print(ma_chaine5)
print(ma_chaine6)
print(ma_chaine6.replace("A", "z"))
print(ma_chaine6.replace("A", "z", 5))

"""
try:
    print(ma_chaine4.index("po"))
except ValueError:
    print("Cette chaine n'existe pas")
else:
    print("La chaine existe")
#print(ma_chaine4)
"""

