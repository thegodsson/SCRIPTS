#coding:utf-8

ageUtilisateur = input("Quel âge as-tu ? ")

try:
    ageUtilisateur = int(ageUtilisateur)
  

except:
    print("L'age indiqué est incorrect !!!")

else:
      print("Tu as ", ageUtilisateur, "ans")

finally:
    print("Fin du programme")