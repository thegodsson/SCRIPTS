"""
chaine = string
Une méthode de chaïne travaille sur une copie , et pas sur la chaîne elle même.

"""

ma_chaine = "Bonjour tout le monde"
ma_chaine2 = "COMMENT ALLEZ VOUS"
ma_chaine3 = "sa vas et vous"
ma_chaine4 = "bien bien"

ma_chaine = ma_chaine.upper()
ma_chaine2 = ma_chaine2.lower()
ma_chaine3 = ma_chaine3.capitalize()
ma_chaine4 = ma_chaine4.title()

#Verification que c'est une copie
ch1 = "Bonjour"
ch2 = ch1

#print(ch1)
#print(ch2)

ch1 = ch1.upper()

#print(ch1)
#print(ch2)



###Programe principal###

#print(ma_chaine)
#print(ma_chaine2)
#print(ma_chaine3)
#print(ma_chaine4)