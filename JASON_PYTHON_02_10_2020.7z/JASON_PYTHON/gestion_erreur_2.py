#coding:utf-8


age = input("Quel age as-tu ? ")
age = int(age)

if age < 25:
    raise ZeroDivisionError