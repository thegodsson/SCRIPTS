#coding:utf-8


#Classe mere
class Vehicule:
    def __init__(self, nom_vehicule, quantite_essence_vehicule):
         self.nom = nom_vehicule
         self.quantite_essence = quantite_essence_vehicule

    def se_deplacer(self):
        print("Le vehicule {} se deplace".format(self.nom))



#Une classe Fille
class Voiture(Vehicule):
    def __init__(self, nom_voiture, quantite_essence_voiture, puissance):
        Vehicule.__init__(self, nom_voiture, quantite_essence_voiture)
        self.puissance = puissance
    
    def se_deplacer(self):
        print("Je roule ...")
        

class Avion(Vehicule):
    def __init__(self, nom_avion, quantite_essence_avion, marchandise):
        Vehicule.__init__(self, nom_avion, quantite_essence_avion)
        self.marchandise = marchandise

    def se_deplacer(self):
        print("Je vole ...")


###Programme principal
voiture1 = Voiture("Toyota", 90, "420 CH")
voiture1.se_deplacer()
print(voiture1.puissance)
avion1 = Avion("Mirage", 50000, "BAGAGES" )
avion1.se_deplacer()
print("{} transporte des {} ".format(avion1.nom, avion1.marchandise))