def inputNumber():
  while True:
    try:
       userInput = int(input("Quel age as tu ? : "))       
    except:
       print("Veuillez entrer un nombre : ")
       continue
    else:
       print("Vous avez {} ans".format(userInput))
       break 


     
 
inputNumber()

