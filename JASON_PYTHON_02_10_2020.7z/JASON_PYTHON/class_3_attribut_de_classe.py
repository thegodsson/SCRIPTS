class Humain:

    """
    Classe des êtres humains
    """

    humain_crees = 0  #Attribut de classe n'appartient pas a l'objet mais a la classe



    #On définit le constructeur
    def __init__(self, c_prenom="TOTO", c_age="40 ans"):
        print("Création d'un humain...")
        #création d'un attribut Un attribut est une variable appartenant à une classe
        self.prenom = c_prenom
        self.age = c_age
        Humain.humain_crees += 1   #Attribut de classe



print("Lancement du programme...")

h1 = Humain("Jojo", "18 ans")
h2 = Humain("TATA", "2 ans")

print("Le nombre d'humains crées est de : {} ".format(Humain.humain_crees))

