#coding:utf-8

import includes.player as player

player.au_revoir()
player.parler("Naruto", "Bonjour")