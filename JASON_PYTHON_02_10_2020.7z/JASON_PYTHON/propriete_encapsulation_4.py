#coding:utf-8


"""
Propriété: manière de manipuler/controller des attribut
"""

class Humain:
    
    """
    Cette classe représenete un humain
    """

    def __init__(self, h_nom, h_age):
        self.nom = h_nom
        self._age = h_age



    def _getage(self):
        if self._age <= 1:
            return str(self._age) + " an"
        else:
            return str(self._age) + " ans"
            

    def _setage(self, nouvel_age):
        if nouvel_age < 0:
            self.age = 0
        else:
            self._age = nouvel_age

           
    def _delage(self):
        del self._age
        
    #property peut predre en compte un : getter, un setter , un deleter , un helper
    age = property(_getage)


####Programme principal####

h1 = Humain("Robert", 20)
print("{} a {}".format(h1.nom, h1.age))

 
