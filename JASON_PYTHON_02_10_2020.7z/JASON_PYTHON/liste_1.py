#Création d'une liste

"""
#1ere syntaxte de creation d'une liste
inventaire = list()
print(type(inventaire))
print(inventaire)
"""

"""
#2eme syntaxe de creation d'une liste , c'est la facon la plus utilisé
inventaire = []
print(inventaire)
"""

"""
#Creation d'une liste avec des éléments prédéfinis
inventaire = [1, 6, 15, "voiture"]
print(inventaire)
"""

"""
#Creation d'une liste avec le meme element repete n fois
inventaire = [0] * 10

#inventaire = ["arc"] * 10
print(inventaire)
"""


#Liste avec des valeur croissante
inventaire = range(20)
"""
#1ere facon de faire , mais pas la plus utilisé


i = 0

while i < len(inventaire):
    print(inventaire[i])
    i += 1
"""

"""
#2eme facon de faire , plus utilisé que le while et plus rapide
for valeur in inventaire:
    print(valeur)
"""


#Autre facon de faire, mais pour récuerer les indices


#inventaire_2 = ["Arc", "épée", "bouclier"]
#inventaire_2 = ["Arc", "épée", "bouclier", "potion", "fleches", "tunique"]


#Arc : indice 0 (1er élément)
#épée : indice 1 (2eme element)


#for valeur in inventaire_2:
 #   print(valeur)

#Affiche tout les éléments
#print(inventaire_2[:])

#Affiche l'élément d'indice 1, donc épée
#print(inventaire_2[1])

#Affiche les 2 premier elements, donc Arc et épée
#print(inventaire_2[:2])


#Affiche les 3 dernier elements Ne fonctionne pas tres bien quand on met 2 a la place de 3, il vaut mieurx utilisé : 
#print(inventaire_2[-2:])

#Affiche le 3eme element en partant de la fin (de la gauche) , docn : potion
#print(inventaire_2[-3])

#De l'élement d'indice 2 donc : bouclier à l'indice 4 donc "fleches", mais l'indice 4 donc fleches, n'est pas affiché, donc ce qui sera afficher sera : bouclier et potion
#print(inventaire_2[2:4])



inventaire_2 = ["Arc", "épée", "bouclier", "potion", "fleches", "tunique"]



"""
print(inventaire_2[:])

#inventaire_2[2] = "bouclier d'acier"
#inventaire_2[:2] = "bouclier d'acier"
#inventaire_2[:2] = ["bouclier d'acier", "bouclier d'acier"]
#inventaire_2[:2] = ["bouclier d'acier"] * 2
#inventaire_2[:] = ["bouclier d'acier"] * 6
#inventaire_2[:] = ["bouclier d'acier"] * len(inventaire_2)
#On remplace les elements "bouclier et "potion" , par "bouclier d'acier", pour connaitre par quel chiffre le multiplié il faut faire B - A  de l'inventaire "inventaire_2[2:4]" , donc 4 - 2 = 2
inventaire_2[2:4] = ["bouclier d'acier"] * 2



print(inventaire_2[:])
"""



inventaire_2 = ["Arc", "épée", "bouclier", "potion", "fleches", "tunique"]

#Recherche dans la liste

if "bouclier" in inventaire_2:
    print("Je possède un bouclier")
else:
    print("Je ne dispose pas de bouclier")





























