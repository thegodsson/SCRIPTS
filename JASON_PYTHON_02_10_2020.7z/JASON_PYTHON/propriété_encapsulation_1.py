#coding:utf-8


"""
Propriété: manière de manipuler/controller des attribut
"""

class Humain:

    def __init__(self, h_nom, h_age):
        self.nom = h_nom
        self._age = h_age



    def _getage(self):
        #print("Recuperation non autorise")
        return self._age

    def _setage(self, nouvel_age):
        if nouvel_age < 0:
            self.age = 0
        else:
            self._age = nouvel_age

           

        
    #property peut predre en compte un : getter, un setter , un deleter , un helper
    age = property(_getage, _setage)


####Programme principal####

h1 = Humain("Jason", 34)
#print("Salut {} tu as {}".format(h1.nom, h1.age))

print(h1.age)
h1.age = -5
print(h1.age)