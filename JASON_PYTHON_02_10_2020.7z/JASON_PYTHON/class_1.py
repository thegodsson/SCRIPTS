class Humain:
    """
    Classe des êtres humains
    """
    #On définit le constructeur
    def __init__(self, c_prenom, c_age):
        print("Création d'un humain...")
        #création d'un attribut Un attribut est une variable appartenant à une classe
        self.prenom = c_prenom
        self.age = c_age
print("Lancement du programme...")

h1 = Humain("Jojo", "18 ans")
h2 = Humain("Titi", "8 ans")


print("Prenom de h1 : {}".format(h1.prenom))
print("Age de h1 : {}".format(h1.age))

print("Prenom de h2 : {}".format(h2.prenom))
print("Age de h2 : {}".format(h2.age))
